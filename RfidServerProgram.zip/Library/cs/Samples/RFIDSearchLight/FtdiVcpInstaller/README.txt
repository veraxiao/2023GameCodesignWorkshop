ftdi_ser.dll -- Signed FTDI VCP driver for Nomad (FTDI VCP 1.1.0.10 for Windows CE 4-5, ARM)
FTDIPORT.INF -- Initial configuration file for FTDI VCP driver
